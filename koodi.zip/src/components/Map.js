import React, { useEffect, useRef } from 'react'
import BikeStations from './BikeStations'
import L from 'leaflet'

const style = {
  width: "100%",
  height: "100%"
}


const Map = ({ markersData }) => {

  // Luodaan kartta
  const mapRef = useRef(null)
  useEffect(() => {
    mapRef.current = L.map('map', {
      center: [60.2, 24.93],
      zoom: 12,
      layers: [
        L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
          attribution:
            '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
        }),
      ]
    });
  }, [])

  // Lisätään taso merkeille
  const layerRef = useRef(null)
  useEffect(() => {
    layerRef.current = L.layerGroup().addTo(mapRef.current)
  }, [])

  // päivitetään merkit
  useEffect(() => {
    layerRef.current.clearLayers()
    markersData.forEach(data => {
      L.marker([data.lat,data.lon], { title: data.name })
      .bindPopup("<b>" + data.name + "</b><br>" + "Vapaat pyörät: " + data.bikesAvailable + "<br>" + "Tyhjät paikat: " + data.spacesAvailable)
      .addTo(layerRef.current)
      
    })
  }, [markersData])

  return (
    <div id="map" style={style} />
  )
}

export default Map